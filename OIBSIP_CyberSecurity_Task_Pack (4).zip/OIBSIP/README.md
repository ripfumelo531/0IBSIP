# OIBSIP — Oasis Infobyte Cyber Security Internship

This repository is a starter pack for the Cyber Security / Security Analyst track.

## Included tasks
- Task 2: Basic UFW firewall configuration (requires a Linux test environment and genuine screenshots).
- Task 4: Common network security threats research report.
- Task 5: Social engineering attacks research report.
- Task 6: Patch management research report.

**Important:** The research reports are drafts to review and personalize. Task 2 has not been executed. Add your own genuine screenshots and test results. Do not claim a practical task is complete until you have performed and documented it.
