# Common Network Security Threats

## Introduction
Network security threats target the confidentiality, integrity, or availability of information and services. This report reviews denial-of-service attacks, man-in-the-middle attacks, IP spoofing, and DNS poisoning/spoofing.

## 1. Denial-of-Service (DoS) and Distributed Denial-of-Service (DDoS)
A DoS attack attempts to make a service unavailable by overwhelming it or exhausting a resource. A DDoS attack uses many systems or devices at once, making traffic harder to filter. A well-known example is the 2016 attack on DNS provider Dyn, which disrupted access to a number of major websites.

**Impact:** service outages, lost revenue, reduced customer trust, and incident-response costs.

**Mitigations:**
- Use reputable DDoS protection and traffic-scrubbing services.
- Apply rate limits and filtering at network edges.
- Maintain an incident-response and continuity plan.

## 2. Man-in-the-Middle (MitM)
A MitM attack occurs when an attacker secretly intercepts or alters communications between parties who believe they are communicating directly.

**Example:** on an unsafe public network, a user may be exposed to an attacker attempting to intercept unprotected traffic.

**Impact:** stolen credentials, altered information, privacy loss, and unauthorized access.

**Mitigations:**
- Use HTTPS/TLS and reject invalid certificate warnings.
- Avoid sensitive activity on untrusted networks; use an approved secure connection.
- Use multi-factor authentication and monitor unusual sign-ins.

## 3. IP Spoofing
IP spoofing is the falsification of the source IP address in network packets. It can be used to disguise traffic origin or support other attacks.

**Example:** attackers may forge source addresses in certain denial-of-service attacks.

**Impact:** makes traffic attribution harder and can undermine trust in network-based controls.

**Mitigations:**
- Apply ingress and egress filtering.
- Use network monitoring and anomaly detection.
- Avoid relying on source IP address alone for authentication.

## 4. DNS Poisoning / DNS Spoofing
DNS poisoning involves corrupting DNS information so a domain name resolves to an unintended address.

**Example:** a user entering a familiar website address could be directed to an imitation site if DNS responses or records have been tampered with.

**Impact:** phishing, credential theft, malware exposure, and loss of trust.

**Mitigations:**
- Use DNSSEC-validating resolvers where supported.
- Secure DNS administration and restrict access to DNS records.
- Monitor DNS changes and use trusted encrypted DNS services where appropriate.

## Comparison
| Threat | Main goal | Typical impact |
|---|---|---|
| DoS/DDoS | Reduce availability | Service outage |
| MitM | Intercept or alter communication | Data or credential exposure |
| IP spoofing | Falsify packet source | Evasion or support for other attacks |
| DNS poisoning | Alter name resolution | Redirection to unintended sites |

## Key takeaways
1. Network threats can affect availability, confidentiality, and integrity.
2. Layered controls are more effective than relying on one security measure.
3. User awareness, monitoring, patching, and secure configuration all contribute to prevention.

## References
- CISA, Understanding and Responding to Distributed Denial-of-Service Attacks: https://www.cisa.gov/
- Cloudflare Learning Center, What is a DDoS attack?: https://www.cloudflare.com/learning/ddos/what-is-a-ddos-attack/
- OWASP, Transport Layer Protection Cheat Sheet: https://cheatsheetseries.owasp.org/
- ICANN, DNSSEC: https://www.icann.org/resources/pages/dnssec-what-is-it-2019-03-05-en
- NIST, Cybersecurity Framework: https://www.nist.gov/cyberframework
