# Task 4 — Common Network Security Threats

Research report file: `network_security_threats_report.md`

Review the report, check its references, and personalize it before submission. This is a research task; no demo video is required according to the task brief.
