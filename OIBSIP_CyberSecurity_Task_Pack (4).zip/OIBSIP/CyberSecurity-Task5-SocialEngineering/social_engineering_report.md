# Social Engineering Attacks

## Introduction
Social engineering is the use of deception or manipulation to persuade people to reveal information, provide access, or take an unsafe action. It targets human decision-making rather than only technical weaknesses.

## 1. Phishing
Phishing messages impersonate trusted organizations or people to persuade recipients to click links, open attachments, or disclose information.

- **Spear phishing:** tailored to a particular person or group.
- **Whaling:** targets senior or high-value individuals.
- **Vishing:** uses voice calls.
- **Smishing:** uses SMS or text messages.

**Example:** a fake delivery notification asks a recipient to follow a link and enter account details.

## 2. Pretexting
Pretexting uses a fabricated story or identity to make a request seem legitimate. For example, someone may falsely claim to be technical support and ask an employee to confirm sensitive account information.

## 3. Baiting
Baiting offers something attractive to encourage an unsafe action, such as an unexpected prize or a supposedly useful file. The lure may lead to credential theft or malicious downloads.

## 4. Real-world cases
- The 2011 RSA incident involved phishing and contributed to compromise of information related to SecurID. It illustrates how a deceptive email can become an entry point.
- The 2020 Twitter incident involved social engineering of employees and unauthorized access to internal tools. It illustrates the importance of access controls and staff training.

## Comparison
| Technique | Typical channel | Warning sign |
|---|---|---|
| Phishing | Email | Unexpected link or attachment |
| Vishing | Phone call | Pressure to disclose information |
| Smishing | SMS | Urgent message with a link |
| Pretexting | Any channel | Unusual request backed by an invented role |
| Baiting | Online or physical lure | Unexpected reward or device |

## Prevention
- Verify unusual requests through a separate, trusted contact method.
- Never share passwords or one-time codes.
- Use multi-factor authentication.
- Report suspicious messages to the appropriate security team.
- Keep devices and software updated.
- Limit access to information based on job needs.

## Five-point awareness checklist
1. Pause when a message creates urgency or fear.
2. Check the sender and destination before interacting.
3. Do not disclose passwords or authentication codes.
4. Confirm financial or sensitive requests independently.
5. Report suspicious activity promptly.

## References
- CISA, Avoiding Social Engineering and Phishing Attacks: https://www.cisa.gov/
- NIST, Phishing guidance and cybersecurity resources: https://www.nist.gov/
- Federal Trade Commission, How to Recognize and Avoid Phishing Scams: https://consumer.ftc.gov/
- Twitter, 2020 security incident updates: https://blog.x.com/
- RSA, 2011 incident information: https://www.rsa.com/
