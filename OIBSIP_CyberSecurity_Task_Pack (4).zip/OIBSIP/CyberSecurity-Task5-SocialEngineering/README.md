# Task 5 — Social Engineering Attacks

Research report file: `social_engineering_report.md`

Review, verify references, and personalize before submission. This is a research task; no demo video is required according to the task brief.
