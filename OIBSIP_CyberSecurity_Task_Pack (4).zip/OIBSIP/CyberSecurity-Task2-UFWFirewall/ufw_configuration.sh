#!/usr/bin/env bash
set -euo pipefail

echo "This script changes firewall settings."
echo "Run ONLY inside a local Linux test VM, never over SSH."
read -r -p "Type LOCAL-VM to continue: " confirm
if [[ "$confirm" != "LOCAL-VM" ]]; then
  echo "Cancelled."
  exit 1
fi

if ! command -v ufw >/dev/null 2>&1; then
  sudo apt update
  sudo apt install -y ufw
fi

sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow 22/tcp
sudo ufw deny 80/tcp
sudo ufw allow 443/tcp
sudo ufw limit 22/tcp
sudo ufw --force enable
sudo ufw status verbose
