# Task 2 — Basic Firewall Configuration with UFW

## Important safety note
Run this only inside a local Ubuntu/Kali virtual machine that you can access from its console. Do not run it on your main Windows system or over a remote SSH connection. Firewall changes can interrupt network access.

## What to demonstrate
1. Install UFW.
2. Set incoming traffic to deny and outgoing traffic to allow.
3. Allow SSH (port 22).
4. Deny HTTP (port 80).
5. Add two additional reasonable rules.
6. Enable UFW and verify its status.
7. Test and document the rules in your isolated lab.

Capture genuine screenshots of the commands and results. Do not use sample or edited screenshots as evidence.
